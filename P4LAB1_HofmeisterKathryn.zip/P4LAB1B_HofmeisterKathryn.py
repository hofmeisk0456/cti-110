import turtle

t = turtle.Turtle()
t.pensize(3)
t.color("black")
t.speed(2)

# --- Draw 'K' ---
t.penup()
t.goto(-100, -50)
t.pendown()

# Vertical line of 'K'
for _ in range(1):
    t.setheading(90)
    t.forward(100)

# Diagonals of 'K'
t.backward(50)
t.setheading(45)
t.forward(50)
t.backward(50)
t.setheading(-45)
t.forward(50)

# --- Move to draw 'H' ---
t.penup()
t.goto(50, -50)
t.setheading(90)
t.pendown()

# Left vertical of 'H'
for _ in range(1):
    t.forward(100)

# Horizontal connector
t.backward(50)
t.setheading(0)
t.forward(50)

# Right vertical of 'H'
t.setheading(90)
t.forward(50)
t.backward(100)

turtle.done()
