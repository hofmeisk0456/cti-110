import turtle

# Set up turtle
t = turtle.Turtle()
t.pensize(3)
t.speed(3)

# --- Draw square using a for loop ---
for _ in range(4):
    t.forward(100)
    t.right(90)

# --- Move slightly to draw triangle ---
t.penup()
t.goto(20, 20)  # small move so both shapes are visible
t.pendown()

# --- Draw triangle using a while loop ---
count = 0
while count < 3:
    t.forward(100)
    t.left(120)
    count += 1

turtle.done()
